@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Installe Node.js 20 ou plus puis relance ce fichier.
  pause
  exit /b 1
)
echo DeusLoader PS5 12.02 - garde cette fenetre ouverte.
node tools/ps5-host.mjs
pause
