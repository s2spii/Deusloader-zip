@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Installe Node.js 20 ou plus puis relance ce fichier.
  pause
  exit /b 1
)
start "DeusLoader" http://127.0.0.1:8787/?mock=12.02
node tools/server.mjs
pause
