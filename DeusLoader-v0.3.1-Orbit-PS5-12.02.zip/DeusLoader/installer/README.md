# Installateur Média — v0.3.0

`payloads/install-media.elf` est un véritable ELF x86-64 construit depuis les sources de PLK et le SDK inclus. Il embarque l’interface et les trois autres payloads ; il ne s’embarque pas lui-même.

1. Héberger l’archive complète sur le PC via `Start-DeusLoader-PS5.cmd`.
2. Sur PS5 12.02, démarrer Minimal jusqu’à READY.
3. Dans la bibliothèque, envoyer Installation Média une fois.
4. Le navigateur ouvre le serveur temporaire local, port 18182. Attendre la fin du cache puis le message de réussite.
5. Fermer la page, ouvrir le raccourci DeusLoader Orbit. Tester ensuite le même raccourci après un redémarrage, sans le serveur PC.

Le lanceur est enregistré sous `/user/app/DEUS00001/sce_sys/`, avec param.json et une icône originale. L’identifiant et le port sont distincts de WKAL00001/18181. La fonction AppInstUtil d’origine enregistre le titre ; l’archive ne contient pas de faux PKG ni d’eboot signé.

L’AppCache embarque uniquement des URLs réellement servies, dont le bridge, son worker, les fichiers Relapse, les configurations et les payloads. Le pointeur contrôle un marqueur de version. La version inclut une empreinte des assets, pour que réinstaller une nouvelle compilation renouvelle le cache. Le flux cache/install/récupération de PLK est conservé ; les textes et l’icône sont adaptés.

Si le cache échoue, ne considérer aucun raccourci comme opérationnel. La page peut proposer d’effacer les données WebKit : ce geste efface également d’autres caches du navigateur et reste un choix explicite. Le chemin LAN reste disponible.

Compilation vérifiée sur PC ; installation, classement Média, persistance du cache et réutilisation après reboot à confirmer sur PS5 12.02. Le jailbreak n’est pas rendu permanent par ce raccourci.
