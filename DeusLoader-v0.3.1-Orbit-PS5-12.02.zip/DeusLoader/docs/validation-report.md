# Rapport v0.3.0 — 2026-10-04

Validations exécutées sur PC :

- 90 tests Node, 90 réussites, zéro échec : pipeline, transports simulés, serveurs HTTP, hashes de tous les snapshots natifs, ELF intégrés, profils et séparation mock/réel.
- Reconstruction complète avec le script livré, sans SDK préinstallé : SDK, libmicrohttpd, microDNS, libsmb2, FTP, serveur Web, notification et installateur Média.
- Quatre vrais ELF64/x86-64 compilés ; leurs tailles et empreintes correspondent aux catalogues.
- 151 URLs AppCache servies par les fichiers embarqués, marqueur versionné en dernière entrée, bridge associé au cache, aucun installateur embarqué dans lui-même.
- 142 assets de distribution statique vérifiés par SHA-256.
- Chromium sur PC : recherche, résultat vide, envoi interdit avant READY, envoi manuel simulé, blocage du doublon, sauvegarde du profil personnalisé, contraste et absence de débordement mobile à 390 px. Affichage du catalogue réel testé avec une UA injectée pour le rendu uniquement ; aucun exploit natif exécuté.
- Captures visuelles PC et mobile inspectées. Le rendu du navigateur PS5 reste à confirmer.
- Vérification GitHub des commits distants par l’outil livré. libsmb2 reste épinglé au tag 6.2 compatible avec les API websrv, plutôt qu’à son HEAD 7.x.

Évidence console : l’utilisateur a confirmé que v0.2 a fonctionné sur sa PS5 12.02. Le snapshot et les trois patches Relapse de cette chaîne restent identiques.

Non validés sur PS5 : exécution des nouveaux services, installation native du titre, son classement exact dans Média, cache AppCache après reboot sans PC, stabilité et taux de succès de v0.3. Les résultats PC ne sont pas des preuves de ces étapes matérielles. Un ELF transféré n’est pas une exécution confirmée.

etaHEN et PS5Debug réels sont exclus ; les helpers binaires fournis par ntfargo dans v0.2 sont conservés, sans reconstruction déclarée.

## Correctifs v0.3.1 — 2026-10-05

102 tests Node réussis, dont les régressions de navigation du Service Worker et les sept états d’indication AppCache. L’installateur reconstruit refuse de créer le raccourci tant que le cache n’est pas IDLE. Trois scénarios ont été exécutés dans Chromium avec la page d’installation générée et un serveur HTTP de test : AppCache absent → aucun appel install ; téléchargement en cours → aucun appel install ; cache prêt → un seul appel install. Ces tests n’enregistrent aucun titre sur une PS5.

Vérification du cache natif : 152 URLs réellement embarquées et marqueur final valide. Distribution : 143 assets vérifiés. Les contrôles UI PC/mobile passent après ces corrections. Le fonctionnement matériel de l’installation et du cache après redémarrage reste à confirmer.
