# Payloads

Le catalogue réel comprend FTP 2121, serveur Web 8080, notification de test et installateur Média 18182. Sources, commit, licence, taille, compatibilité déclarée et SHA-256 sont visibles sur chaque carte. La cible est 12.02, selon le SDK utilisé ; la validation matérielle des nouveaux ELF est en attente.

Une session READY permet l’envoi manuel avec le même loader et le même contrôle d’empreinte que l’autoload. Les envois sont séquentiels. Les doublons dans une session sont bloqués après transfert réussi. Un transport réussi ne certifie pas l’exécution ; la notification de test sert à la confirmer visuellement.

`node tools/add-payload.mjs /chemin/fichier.elf mon-id "Mon payload"` peut importer un ELF local : format ELF64/x86-64 et SHA-256 sont vérifiés, sans certification de compatibilité. `npm run build:native` régénère le catalogue officiel et les profils ; sauvegarder vos ajouts avant cette commande. Un payload ajouté après construction de l’installateur n’apparaît pas automatiquement dans son cache embarqué.

etaHEN réel et PS5Debug réel sont absents. Les noms présents en mode mock sont des démonstrations exclusivement, jamais des fichiers réels de remplacement.
