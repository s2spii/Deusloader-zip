# Validation console

Sur PC : npm run verify, npm run sources:verify et npm run build:native. Les tests de transport sont des doubles de syscalls. Les tests d’interface utilisent une simulation, sans exécuter Relapse.

Sur PS5 12.02 : d’abord Minimal jusqu’à READY ; envoyer Notification test et constater le message. Envoyer FTP et vérifier connexion au port 2121. Envoyer Serveur Web et vérifier l’interface sur 8080. Enfin envoyer Installation Média, attendre le cache et l’enregistrement du titre, puis tester le raccourci et recommencer après reboot sans PC.

Relever temps par étape, journal exporté, résultat de chaque service et persistance du cache. Un transfert ou une compilation ne doit pas être compté comme une exécution matérielle réussie.
