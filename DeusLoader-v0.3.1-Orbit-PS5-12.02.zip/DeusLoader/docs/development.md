# Développement

Node.js 20+ pour l’hôte et les tests JavaScript. Pas de dépendance npm de production. `npm run verify` vérifie les configurations, imports,  empreintes, tests et distribution statique.

Pour les ELF : Linux/WSL, Python 3.12+, Git, Make, LLVM/Clang/LLD 18+ avec llvm-config, CMake, Meson/Ninja, pyelftools. `npm run build:native` construit le SDK inclus si PS5_PAYLOAD_SDK n’est pas fourni, puis les dépendances et les quatre payloads. Les sources sont vérifiées avant exécution de leur compilation.

Les copies et fichiers générés vont dans .native-build, les ELF dans payloads et les manifestes dans config/public. L’installateur n’est jamais embarqué dans lui-même. Pour mettre à jour depuis GitHub, voir updates.md. Une reconstruction régénère les profils officiels ; préserver les ajouts personnels avant de lancer cette commande.
