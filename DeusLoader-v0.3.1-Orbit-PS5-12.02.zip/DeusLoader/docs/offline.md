# Hors ligne

Au premier lancement LAN HTTP, le PC sert tous les fichiers. Les empreintes de payload utilisent SHA-256 JS si WebCrypto est absent. Le Service Worker n’est disponible que sur localhost/HTTPS.

L’installation Média utilise l’AppCache du navigateur PS5 via le serveur local temporaire du payload. L’interface, son bridge et son worker, les helpers Relapse, les catalogues et trois payloads sont embarqués dans l’ELF installateur. Celui-ci attend que le cache soit courant avant d’enregistrer le titre. Le pointeur vérifie un marqueur versionné.

Les URLs alternatives des exploits non intégrés sont retirées du manifeste, et le bridge est associé au groupe AppCache. Une nouvelle compilation obtient un nouveau répertoire de cache. Le lancement hors ligne après reboot reste à confirmer sur la console ; la présence d’un raccourci seule ne suffit pas. Aucun dossier USB de type Y2JB n’est fourni.
