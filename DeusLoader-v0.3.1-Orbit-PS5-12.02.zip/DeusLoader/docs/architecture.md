# Architecture

L’interface observe la machine d’état Relapse ; le runner détecte le firmware, initialise le bridge, lance WebKit, confirme le kernel, démarre ELF Loader, puis exécute l’autoload. L’envoi manuel utilise son loader seulement après READY. Les catalogues réel et mock restent distincts.

Le bridge same-origin garde le document natif vivant. L’origine et la fenêtre émettrice de chaque RPC sont contrôlées. Les attentes sont bornées ; une session native abandonnée est verrouillée. Le transport utilise les syscalls de la console et gère les écritures partielles vers 127.0.0.1:9021.

Le pipeline natif vérifie les sources épinglées, construit SDK/dépendances/payloads, produit le frontend, l’embarque dans l’installateur PLK adapté et calcule les empreintes de distribution. Le cache versionné contient le bridge et les ELF, avec un pointeur stable /app/index.html. Les sources C ne sont pas servies par l’hôte LAN.
