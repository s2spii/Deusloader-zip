# Sources

Relapse MIT ntfargo est inchangé dans upstream ; config/upstream-lock.json épingle 50 fichiers au commit dd8e4e0914c5e9d066ee1f9b056be76cb992c8e0. La copie runtime adapte trois points documentés dans src/exploit/relapse/README.md. Ses deux helpers binaires restent ceux de v0.2.

Les sources natifs sont épinglées fichier par fichier dans native/sources.lock.json. FTP, serveur Web, SDK, microDNS et SMB viennent des dépôts GitHub déclarés ; libmicrohttpd 1.0.1 est la tarball source GNU, incluse et vérifiée. L’installateur est dérivé de ps5-webkit-autoloader (PLK).

native/build.py vérifie les sources, construit les ELF et crée les catalogues. Les modifications de l’installateur sont générées dans une copie : titre DEUS00001, port 18182, nom de processus distinct, icône originale, frontend DeusLoader, AppCache sans URLs inexistantes, manifest sur le bridge, version par empreinte. Les fichiers source originaux restent inchangés.

Les sources etaHEN au commit dafa13b562ddb137a4b4a97b9aaa287c0c57cc9c ont été examinées ; leur table libhijacker/source/offsets.cpp s’arrête à 10.60. Elles ne sont pas redistribuées, ni compilées en payload 12.02. L’exclusion est enregistrée dans le rapport des sources.
