# Dépannage

URL LAN inaccessible : garder la fenêtre Node ouverte, vérifier le réseau commun, l’adresse affichée et le pare-feu privé. Une adresse 0.0.0.0 n’est pas une URL à ouvrir sur la console.

Firmware inconnu : ouvrir le navigateur PS5 12.02. Aucun forçage de firmware réel n’est prévu. La simulation PC utilise ?mock=12.02.

Échec natif ou timeout : redémarrer la PS5 avant une autre tentative. Ne pas ouvrir une deuxième chaîne en parallèle. Les détails et exports du journal aident à identifier l’étape.

FTP/Web transféré mais inaccessible : une transmission seule ne confirme pas l’exécution. Vérifier IP de la console, ports 2121/8080 et état du réseau. La notification de test permet de constater une exécution locale.

Installation/cache incomplet : ne pas présumer que le raccourci fonctionne. Relancer depuis le PC puis réenvoyer l’installateur après une session prête. Effacer les données WebKit si proposé efface aussi les autres caches ; ce choix appartient à l’utilisateur. Garder l’archive v0.2 disponible comme référence connue.
