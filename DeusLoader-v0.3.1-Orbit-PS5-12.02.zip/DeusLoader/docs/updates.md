# Mise à jour depuis les sources

`npm run sources:check` compare les commits épinglés aux HEAD GitHub. `node tools/update-sources.mjs update ID SHA_COMPLET` récupère les sources à ce commit et renouvelle le verrou. IDs : ftpsrv, websrv, payload-sdk, ps5-webkit-autoloader, libmicrodns, libsmb2.

Le snapshot de websrv exclut les exemples homebrew et l’hôte PC, non utilisés pour le payload. Aucun ELF de release n’est importé par cet outil. Les dépôts sont limités à une liste fixe. Les sources épinglées restent dans native/upstream ; les copies de compilation et patchs sont dans .native-build.

Construire avec `npm run build:native`, puis `npm run verify`. Cela recalcule les ELF, SHA-256, catalogue et installateur. Pour un changement de SDK, reconstruire le SDK également ; un SDK externe doit correspondre à la version souhaitée. Les dépendances natives sont invalidées quand leurs commits changent. Meson, CMake et LLVM doivent être installés sur le PC de compilation.

Contrôler le support 12.02, les nouvelles API, licences et ancres de patch avant de diffuser une mise à jour. L’outil échoue si une ancre d’intégration a disparu. Un nouveau commit n’implique pas automatiquement qu’il est adapté à la console.

Héberger la nouvelle version sur PC, relancer Minimal puis envoyer Installation Média. Le cache a une version basée sur l’empreinte des fichiers ; il contient l’interface, les configurations et trois payloads, sans dépendance à GitHub au lancement. Les profils personnalisés dépendent des IDs et sont conservés localement, ou ignorés si devenus invalides.

La mise à jour Relapse est distincte : config/upstream-lock.json, snapshot MIT, revue des trois patches, tests puis validation console. La version qui a fonctionné reste épinglée. Aucun outil ne met à jour le firmware de la PS5.
