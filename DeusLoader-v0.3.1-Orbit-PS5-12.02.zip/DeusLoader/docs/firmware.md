# Firmware

Cible réelle unique : PS5 12.02. Le lancement réel requiert une détection PlayStation 5 ; un navigateur PC n’est jamais accepté comme console. Les offsets Relapse restent ceux de la version v0.2 confirmée par l’utilisateur.

Le SDK épinglé contient le cas 0x12020000 dans crt/kernel.c. Les nouveaux payloads sont construits avec ce SDK. Ceci documente leur base de compatibilité et ne certifie pas encore leur fonctionnement matériel. Les autres firmwares sont refusés par l’application.
