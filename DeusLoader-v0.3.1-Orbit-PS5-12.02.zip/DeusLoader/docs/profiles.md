# Profils

Minimal : aucun payload. Connecté : FTP. Diagnostic : notification, FTP et serveur Web. Ma composition : liste persistante construite avec « + Profil », puis ordre, délais et dépendances modifiables dans l’éditeur JSON.

Les profils mock et réels ont leurs propres catalogues et clés de stockage. La sélection réelle est mémorisée ; le premier lancement utilise Minimal. Un profil invalide enregistré est ignoré et journalisé. Les changements après READY s’appliquent au prochain lancement ; les boutons Envoyer utilisent la session présente.

Les dépendances doivent précéder le payload qui en dépend. Les délais sont bornés à 30 secondes. Les payloads facultatifs peuvent échouer sans interrompre la session ; un payload obligatoire l’interrompt. Les retries natifs sont forcés à zéro pour éviter une seconde transmission après erreur ambiguë.
