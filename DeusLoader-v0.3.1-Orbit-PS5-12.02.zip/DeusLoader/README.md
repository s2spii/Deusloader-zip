# DeusLoader Orbit v0.3.1 — PS5 12.02

Interface française, profils persistants, catalogue local et installateur de raccourci Média. La chaîne Relapse est celle de v0.2, dont le fonctionnement sur PS5 12.02 a été confirmé par l’utilisateur. Les nouveaux payloads et l’installation Média sont compilés et vérifiés sur PC ; leur fonctionnement sur la console reste à confirmer.

## Démarrage

1. Extraire toute l’archive sur le PC. Installer Node.js 20+.
2. PC et PS5 sur le même réseau local : lancer `Start-DeusLoader-PS5.cmd`.
3. Ouvrir l’URL affichée, `http://IP-DU-PC:8787/`, avec la méthode d’accès au navigateur qui a fonctionné pour v0.2.
4. Sur PS5 12.02, garder **Minimal · ELF Loader seul** et lancer la session.
5. Une fois **READY**, la bibliothèque permet d’envoyer un payload. Une transmission réussie ne confirme pas à elle seule son exécution.

| Payload intégré | Usage | Origine des sources |
| --- | --- | --- |
| Serveur FTP | Accès aux fichiers depuis le PC, port 2121 | ps5-payload-dev/ftpsrv |
| Serveur Web | Gestion homebrew/fichiers, port 8080 | ps5-payload-dev/websrv |
| Notification test | Message visible sur la PS5 | Sample hello_world du SDK, adapté |
| Installation Média | Cache embarqué et raccourci DeusLoader | itsPLK/ps5-webkit-autoloader, adapté |

Ces quatre ELF ont été construits depuis les sources incluses, sans récupérer leurs binaires de release GitHub. Commits, licences et SHA-256 : `public/source-report.json` et `native/sources.lock.json`. Le SDK contient une entrée 12.02 ; cela ne remplace pas un essai matériel de chaque payload.

## Installation dans Média

Après une session Minimal prête, envoyer **Installation Média**. L’ELF lance la page locale `http://127.0.0.1:18182/`, remplit le cache AppCache, puis enregistre le raccourci **DeusLoader Orbit**, titre **DEUS00001**. Attendre le message d’installation réussie avant de fermer la page. Le raccourci ouvre `/app/index.html`, qui vérifie le marqueur de la version puis lance l’interface mise en cache.

Ce mécanisme ajoute un lanceur navigateur à la console. Ce n’est pas un PKG signé ni une installation Y2JB. Le cache après redémarrage et le classement exact dans Média doivent être validés sur votre console. En cas d’échec, revenir au lancement LAN de v0.3 ou de la v0.2 conservée séparément. [Guide d’installation](installer/README.md).

## Profils et bibliothèque

Minimal lance le loader seul. Connecté ajoute FTP. Diagnostic ajoute notification, FTP et serveur Web. « + Profil » compose **Ma composition** ; l’éditeur JSON ajuste l’ordre, les dépendances et les délais. La sélection et le profil se conservent localement. Modifier un profil après READY prépare le prochain lancement ; l’envoi manuel agit sur la session courante.

Les payloads réels ne sont jamais remplacés par les fixtures de simulation. Les transferts réels ne sont pas réessayés automatiquement. Un payload déjà envoyé dans cette session ne peut pas être envoyé à nouveau par son bouton.

## Sources et mises à jour

Sur Linux/WSL Ubuntu avec Git, Node.js, Python 3.12+, LLVM/Clang/LLD 18+, Make, CMake, Meson et Ninja :

```sh
python3 -m pip install pyelftools meson ninja
npm run sources:verify
npm run build:native
npm run verify
```

Sans variable `PS5_PAYLOAD_SDK`, le SDK inclus est lui aussi compilé dans `.native-build/sdk`. Les dépendances sont construites depuis les sources incluses. Un SDK déjà construit peut être fourni avec cette variable. Aucune connexion n’est requise pour reconstruire si les outils de compilation sont installés.

```sh
npm run sources:check
node tools/update-sources.mjs update ftpsrv SHA_COMPLET_DU_COMMIT
npm run build:native
npm run verify
```

L’outil récupère les sources Git du projet choisi, vérifie le commit et met à jour le verrou. Une nouvelle version peut changer ses API ou sa compatibilité : les ancres de patch doivent alors être adaptées. Après reconstruction, héberger la nouvelle version sur PC et renvoyer son installateur pour actualiser le cache de la console. [Détails](docs/updates.md).

## Limites connues

- etaHEN n’est pas intégré : la table d’offsets des sources publiques auditées s’arrête à 10.60. Aucun support 12.02 n’a été inventé. PS5Debug réel n’est pas inclus.
- Les deux helpers de Relapse (`kexp_2026_05_25.bin`, `elfldr-ps5-1360.elf`) restent les fichiers fournis dans le dépôt ntfargo épinglé de v0.2 ; ils ne sont pas reconstruits par cette nouvelle pipeline.
- Une seule tentative Relapse native par page. Après un blocage ou timeout natif, redémarrer la PS5 avant une autre tentative. Un timeout JavaScript n’arrête pas forcément le code natif.
- Le cache PC via Service Worker nécessite HTTPS ou localhost. Le LAN HTTP reste nécessaire au premier lancement ; le mode installé utilise le mécanisme AppCache de la PS5.

## Tests et licences

`npm run verify` contrôle configurations, imports, empreintes et tests. La simulation PC est accessible via `Start-DeusLoader.cmd` / `?mock=12.02` ; elle n’exécute aucun exploit. [Rapport](docs/validation-report.md).

Code original de l’interface : MIT. Composants natifs : GPL-3.0 et dépendances LGPL/BSD selon leurs notices. Les sources et modifications nécessaires à leur reconstruction sont incluses. [Notices](THIRD_PARTY_NOTICES.md).

## Correctifs v0.3.1

Le Service Worker conserve le document bridge lors d’une navigation iframe. L’indicateur AppCache suit désormais les états réels, avec actualisation pendant la vérification, le téléchargement et l’invalidation. L’installateur refuse aussi de créer un raccourci si AppCache est absent ou incomplet. Ces correctifs sont aussi embarqués dans l’installateur reconstruit.
