#!/usr/bin/env python3
"""Build bundled payloads from locked, vendored source. No release ELF downloads."""
from pathlib import Path
import os, sys, json, hashlib, shutil, subprocess, tarfile
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'.native-build'
LOCK=json.loads((ROOT/'native/sources.lock.json').read_text())
VERSION=json.loads((ROOT/'package.json').read_text())['version']
def run(args,cwd=ROOT,env=None):
    print('+', ' '.join(map(str,args)),flush=True)
    subprocess.run(list(map(str,args)),cwd=cwd,env=env or os.environ,check=True)
def fresh_copy(src,dst):
    if dst.exists():shutil.rmtree(dst)
    shutil.copytree(src,dst)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def writejson(p,data): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def replace(p,old,new):
    s=p.read_text()
    if old not in s: raise RuntimeError('Patch anchor missing: '+str(p))
    p.write_text(s.replace(old,new))
def verify_sources():
    for source in LOCK['sources']:
        for f in source['files']:
            p=ROOT/'native/upstream'/source['id']/f['path']
            if digest(p)!=f['sha256']: raise RuntimeError('Source modified: '+str(p))
    for f in LOCK['dependencies']:
        if digest(ROOT/'native/deps'/f['file'])!=f['sha256']: raise RuntimeError('Dependency hash mismatch')
def entry(id,name,file,source,**extra):
    p=ROOT/'payloads'/file
    return dict(id=id,name=name,file=file,version=source['commit'][:10],compatibility={'firmwares':['12.02']},integrity={'sha256':digest(p)},bytes=p.stat().st_size,source={k:source[k] for k in ['repository','commit','license']},hardwareValidation='pending',**extra)
verify_sources()
if '--verify-sources' in sys.argv: print('Locked native source hashes verified');sys.exit(0)
BUILD.mkdir(exist_ok=True)
sdk=Path(os.environ.get('PS5_PAYLOAD_SDK',BUILD/'sdk')).resolve()
sdk_source=next(s for s in LOCK['sources'] if s['id']=='payload-sdk')
sdk_stamp=sdk/'.deus-sdk-commit'
owned_sdk='PS5_PAYLOAD_SDK' not in os.environ
if not (sdk/'bin/prospero-clang').exists() or (owned_sdk and (not sdk_stamp.exists() or sdk_stamp.read_text()!=sdk_source['commit'])):
    sdk_src=BUILD/'sdk-source'
    fresh_copy(ROOT/'native/upstream/payload-sdk',sdk_src)
    if owned_sdk and sdk.exists():shutil.rmtree(sdk)
    run(['make','-j4','DESTDIR='+str(sdk),'install'],cwd=sdk_src)
    sdk_stamp.write_text(sdk_source['commit'])
env=dict(os.environ,PS5_PAYLOAD_SDK=str(sdk));env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']
cc=sdk/'bin/prospero-clang'
dep_stamp=sdk/'.deus-dependencies.json'
wanted_deps={x['id']:x['commit'] for x in LOCK['sources'] if x['id'] in ['libmicrodns','libsmb2']}
wanted_deps['microhttpd']=LOCK['dependencies'][0]['sha256']
try: previous_deps=json.loads(dep_stamp.read_text())
except (FileNotFoundError,ValueError): previous_deps={}
if previous_deps.get('microhttpd')!=wanted_deps['microhttpd'] or not (sdk/'target/lib/libmicrohttpd.a').exists():
    dep=LOCK['dependencies'][0]
    with tarfile.open(ROOT/'native/deps'/dep['file']) as tf: tf.extractall(BUILD,filter='data')
    micro=BUILD/'libmicrohttpd-1.0.1'
    depenv=dict(env,CC=str(cc),AR=str(sdk/'bin/prospero-ar'),NM=str(sdk/'bin/prospero-nm'),RANLIB=str(sdk/'bin/prospero-ranlib'),CFLAGS='-O1')
    run(['./configure','--host=x86_64-pc-freebsd12','--disable-shared','--enable-static','--disable-curl','--disable-examples','--disable-https','--prefix='+str(sdk/'target')],cwd=micro,env=depenv)
    run(['make','-j4'],cwd=micro,env=depenv);run(['make','install'],cwd=micro,env=depenv)
# Web server dependencies are also rebuilt from locked GitHub source trees.
if previous_deps.get('libmicrodns')!=wanted_deps['libmicrodns'] or not (sdk/'target/lib/libmicrodns.a').exists():
    dns=BUILD/'libmicrodns-source';fresh_copy(ROOT/'native/upstream/libmicrodns',dns)
    dns_build=BUILD/'libmicrodns-build'
    if dns_build.exists():shutil.rmtree(dns_build)
    run(['python3','-m','mesonbuild.mesonmain','setup',dns_build,dns,'--cross-file',sdk/'toolchain/prospero.ini','--prefix='+str(sdk/'target'),'-Ddefault_library=static','-Dtests=disabled','-Dexamples=disabled'],env=env)
    run(['python3','-m','mesonbuild.mesonmain','compile','-C',dns_build],env=env)
    run(['python3','-m','mesonbuild.mesonmain','install','-C',dns_build],env=env)
if previous_deps.get('libsmb2')!=wanted_deps['libsmb2'] or not (sdk/'target/lib/libsmb2.a').exists():
    smb=BUILD/'libsmb2-source';fresh_copy(ROOT/'native/upstream/libsmb2',smb)
    smb_build=BUILD/'libsmb2-build'
    if smb_build.exists():shutil.rmtree(smb_build)
    run(['cmake','-S',smb,'-B',smb_build,'-DCMAKE_TOOLCHAIN_FILE='+str(sdk/'toolchain/prospero.cmake'),'-DCMAKE_INSTALL_PREFIX='+str(sdk/'target'),'-DENABLE_LIBKRB5=OFF','-DENABLE_GSSAPI=OFF','-DENABLE_EXAMPLES=OFF'],env=env)
    run(['cmake','--build',smb_build,'-j4'],env=env);run(['cmake','--install',smb_build],env=env)
writejson(dep_stamp,wanted_deps)
web=BUILD/'websrv';fresh_copy(ROOT/'native/upstream/websrv',web)
web_source=next(x for x in LOCK['sources'] if x['id']=='websrv')
web_elf=web/'websrv-ps5.elf'
if web_elf.exists():web_elf.unlink()
run(['make','VERSION_TAG='+web_source['commit'][:10],'LDADD=-lkernel_sys -lSceSystemService -lSceUserService -lSceAppInstUtil -lSceSsl -lSceHttp -lmicrohttpd -lmicrodns -lsmb2'],cwd=web,env=env)
run([sdk/'bin/prospero-strip',web_elf],env=env)
shutil.copy(web_elf,ROOT/'payloads/websrv.elf')
ftp=BUILD/'ftpsrv';fresh_copy(ROOT/'native/upstream/ftpsrv',ftp)
source={x['id']:x for x in LOCK['sources']}
run(['make','ftpsrv-ps5.elf','VERSION_TAG='+source['ftpsrv']['commit'][:10]],cwd=ftp,env=env)
shutil.copy(ftp/'ftpsrv-ps5.elf',ROOT/'payloads/ftpsrv.elf')
run([cc,'-Os',ROOT/'native/notification/main.c','-o',ROOT/'payloads/notification.elf'],env=env)
payloads=[entry('ftpsrv','Serveur FTP','ftpsrv.elf',source['ftpsrv'],category='service',icon='⇅',description='Transférez vos fichiers sur le réseau local. FTP : port 2121. Accès au système de fichiers de la console.'),entry('notification','Notification test','notification.elf',source['payload-sdk'],category='utility',icon='✦',description='Affiche un message sur la PS5 pour confirmer visuellement l’exécution d’un ELF. Dérivé du sample hello_world.')]
payloads.insert(1,entry('websrv','Serveur Web','websrv.elf',source['websrv'],category='service',icon='▦',description='Interface de gestion homebrew et fichiers depuis votre réseau local. Ouvrez http://IP-DE-LA-PS5:8080 sur votre PC.'))
writejson(ROOT/'config/real-payloads.json',{'schema':1,'payloads':payloads})
def item(id,delay=750):return dict(id=id,enabled=True,required=False,delay=delay,retries=0,when={'after':[]})
writejson(ROOT/'config/real-profiles.json',{'schema':1,'profiles':[{'id':'minimal','name':'Minimal · ELF Loader seul','payloads':[]},{'id':'normal','name':'Connecté · Serveur FTP','payloads':[item('ftpsrv')]},{'id':'dev','name':'Diagnostic · Notification + FTP + Web','payloads':[item('notification'),item('ftpsrv',1500),item('websrv',1500)]},{'id':'custom','name':'Ma composition','payloads':[]}]})
report={'version':VERSION,'policy':'Payloads compiled from source; no GitHub release ELF downloads','sources':[{k:v for k,v in s.items() if k!='files'} for s in LOCK['sources']],'excluded':LOCK['excluded'],'payloads':payloads}
writejson(ROOT/'public/source-report.json',report)
# Do not embed the installer in itself. Only service/utility ELF files go into the native AppCache.
old=ROOT/'payloads/install-media.elf'
if old.exists(): old.unlink()
run(['npm','run','build'])
inst=BUILD/'installer';fresh_copy(ROOT/'native/upstream/ps5-webkit-autoloader',inst)
replace(inst/'include/wkali.h','"0.5.2"','"'+VERSION+'"')
replace(inst/'include/wkali.h','18181','18182');replace(inst/'include/wkali.h','WKAL00001','DEUS00001');replace(inst/'include/wkali.h','"wkali.elf"','"deusinst.elf"')
replace(inst/'assets/param.json.template','WKAL00001','DEUS00001');replace(inst/'assets/param.json.template','18181','18182');replace(inst/'assets/param.json.template','WebKit Autoloader','DeusLoader Orbit')
# Reuse audited upstream installer/cache/recovery logic, brand only the presentation.
for f in (inst/'src').glob('*.c'):
    f.write_text(f.read_text().replace('WebKit Autoloader','DeusLoader Orbit'))
page=inst/'frontend/installer-page/index.html'
s=page.read_text().replace('WebKit Autoloader','DeusLoader Orbit').replace('#0f172a','#11121b').replace('#0b1220','#191523').replace('#e2e8f0','#eff3f0')
s=s.replace('var hasUmtx2 = isUmtx2Supported(fwNum);','var hasUmtx2 = false;').replace('var hasPoops = isPoopsSupported(fwNum);','var hasPoops = false;').replace('var hasRelapse = isRelapseSupported(fwNum, fwStr);',"var hasRelapse = fwStr === '12.02';").replace("var isDualSupported = (hasPoops && hasRelapse) || (!fw && !fwParam);",'var isDualSupported = false;')
s=s.replace('supported: 1.00–5.50 via umtx2, 7.00–12.00 via poops, 7.00–13.60 via relapse','DeusLoader cible uniquement PS5 12.02').replace('The DeusLoader Orbit shortcut is now on your PS5 homescreen. You can close this page.','Le raccourci DeusLoader est installé. Vous pouvez fermer cette page.').replace('Caching content...','Mise en cache de DeusLoader…').replace('Please wait a moment. Do not close this page yet!','Patientez jusqu’à la fin. Gardez cette page ouverte.')
# A shortcut must never be registered without a completed browser cache.
anchor="""      function maybeInstall() {
        if (completed) {
          return;
        }
        completed = true;"""
replacement="""      function maybeInstall() {
        if (completed) {
          return;
        }
        if (!window.applicationCache || window.applicationCache.status !== window.applicationCache.IDLE) {
          completed = true;
          setFailed();
          detailEl.textContent = 'Cache console absent ou incomplet. Aucun raccourci n’a été installé.';
          return;
        }
        completed = true;"""
if anchor not in s: raise RuntimeError('Installer readiness patch anchor missing')
s=s.replace(anchor,replacement)
page.write_text(s)
# Restrict this one-time installation service to the console itself.
main=inst/'src/main.c'
replace(main,'#include <microhttpd.h>','#include <microhttpd.h>\n#include <netinet/in.h>\n#include <arpa/inet.h>')
replace(main,'    daemon = MHD_start_daemon(', '    struct sockaddr_in local_addr = {0};\n    local_addr.sin_len = sizeof(local_addr);\n    local_addr.sin_family = AF_INET;\n    local_addr.sin_port = htons(WKALI_PORT);\n    local_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);\n    daemon = MHD_start_daemon(')
replace(main,'MHD_OPTION_THREAD_POOL_SIZE, (unsigned int)8,','MHD_OPTION_SOCK_ADDR, (struct sockaddr *)&local_addr,\n                              MHD_OPTION_THREAD_POOL_SIZE, (unsigned int)8,')
# Generate only our actual cache URLs: upstream generator lists absent alternative exploit pages.
generator=inst/'tools/gen_file_registry.py'
g=generator.read_text()
for line in ['    lines.append(poops_iframe_url(app_dir))\n','    lines.append(relapse_iframe_url(app_dir))\n','    lines.append(umtx2_iframe_url(app_dir))\n','    lines.append(app_dir + "/selected_exploit")\n']:g=g.replace(line,'')
generator.write_text(g)
# Dist hash makes AppCache and pointer updates independent of stale versioned files.
build_hash=hashlib.sha256((ROOT/'public/cache-manifest.json').read_bytes()).hexdigest()[:10]
build_version=VERSION+'-'+build_hash
buildenv=dict(env,BUILD_TYPE='stable',CUSTOM_VERSION=build_hash,FORCE_EXPLOIT='relapse')
run(['python3','tools/gen_version.py'],cwd=inst,env=buildenv)
stage=inst/'frontend/dist'
if stage.exists():shutil.rmtree(stage)
stage.mkdir(parents=True)
shutil.copytree(inst/'frontend/installer-page',stage,dirs_exist_ok=True)
for f in ['logo.svg','favicon.svg']:shutil.copy(ROOT/'assets/logo.svg',stage/f)
shutil.copytree(inst/'frontend/pointer',stage/'app',dirs_exist_ok=True)
shutil.copytree(ROOT/'dist',stage/'app'/build_version,dirs_exist_ok=True)
# Associate each iframe document with AppCache for offline fetches after native server exits.
for f in [stage/'app'/build_version/'index.html',stage/'app'/build_version/'src/exploit/relapse/bridge.html',stage/'app/index.html']:
    text=f.read_text();text=text.replace('<html lang="fr">','<html lang="fr" manifest="/cache.appcache">').replace('<html lang="en">','<html lang="en" manifest="/cache.appcache">')
    if 'manifest=' not in text:text=text.replace('<html>','<html manifest="/cache.appcache">')
    f.write_text(text.replace('WebKit Autoloader','DeusLoader Orbit'))
(stage/'VERSION').write_text(build_version)
# Supplied pre-generated PNG is an original DeusLoader app icon, no source payload binary involved.
shutil.copy(ROOT/'assets/media-icon.png',inst/'assets/icon0.png')
run(['python3','tools/gen_file_registry.py',stage,'include/file_registry.h','include/file_registry.c'],cwd=inst,env=buildenv)
src=['main','http_server','app_installer','notification','ps5_launcher','log','inflate','webkit_cleaner','simulate_corrupt']
run([cc,'-Os','-Wall','-ffunction-sections','-fdata-sections','-Iinclude','-I'+str(sdk/'target/include'),'-Wl,--gc-sections','-o','installer.elf',*[f'src/{f}.c' for f in src],'include/file_registry.c',sdk/'target/lib/libmicrohttpd.a','-L'+str(sdk/'target/lib'),'-lpthread','-lSceNetCtl','-lSceUserService','-lSceSystemService','-lSceAppInstUtil'],cwd=inst,env=buildenv)
run([sdk/'bin/prospero-strip','installer.elf'],cwd=inst,env=buildenv)
shutil.copy(inst/'installer.elf',ROOT/'payloads/install-media.elf')
payloads.append(entry('install-media','Installation Média','install-media.elf',source['ps5-webkit-autoloader'],category='installer',icon='↗',description='Embarque DeusLoader et ses payloads. Installe un raccourci navigateur avec cache local, titre DEUS00001. Port 18182.'))
writejson(ROOT/'config/real-payloads.json',{'schema':1,'payloads':payloads});report['payloads']=payloads;report['nativeCacheVersion']=build_version;writejson(ROOT/'public/source-report.json',report)
# Leave inspected native stage available for packaging verification, but never expose C source via the host.
writejson(ROOT/'native/build-result.json',{'version':VERSION,'cacheVersion':build_version,'titleId':'DEUS00001','port':18182,'payloads':payloads})
run(['npm','run','build'])
run(['python3','native/verify-build.py'])
print('Source-built payloads and Media installer ready; hardware validation pending.')
