# Third-party notices — v0.2

## Relapse-Exploit (included)

- Authors: Nathan Fargo (ntfargo), Sonic_Iso, Jordy, ufm42, Dr. Yenyen; further credits in the original README.
- Repository: https://github.com/ntfargo/Relapse-Exploit
- Commit: `dd8e4e0914c5e9d066ee1f9b056be76cb992c8e0`
- Published repository licence: MIT, copyright (c) 2026 Nathan Fargo.
- Original notice: `src/exploit/relapse/upstream/LICENSE`, retained verbatim alongside the original README and complete copied tree.
- Pristine files: 50, individually SHA-256-pinned in config/upstream-lock.json.
- Binary artifacts: the exact `kexp_2026_05_25.bin` and `elfldr-ps5-1360.elf` shipped in that pinned repository, not rebuilt or renamed. Their hashes are pinned and checked before use.
- Modifications: original tree unchanged. Generated runtime modifies three files: main.js worker/offset loading paths, relapse_exploit.js awaited confirmed-kernel checkpoint, kexp.js verified-binary provider. All original source and patches are distributed.

The root DeusLoader MIT licence covers its original code; it does not remove third-party notices or independently assign a new licence to copied binaries. Refer to the upstream's distribution and embedded component sources for their provenance. elfldr's independent project https://github.com/ps5-payload-dev/elfldr declares GPLv3+; its separately built releases must retain that licence and corresponding-source obligations. This preview reproduces ntfargo's bundled artifacts and published notices rather than claiming an independent ELF rebuild or source-to-binary match.

## Native payloads, installer and dependencies — v0.3

Corresponding source snapshots and their notices are retained in native/upstream. native/sources.lock.json identifies commits and hashes. native/build.py and native/notification/main.c contain the complete project changes needed to rebuild the four bundled ELF payloads.

- ps5-payload-dev/ftpsrv and ps5-payload-dev/websrv: John Törnblom and contributors, GPL-3.0-or-later. Preserve LICENSE and per-file notices.
- ps5-payload-dev/sdk: John Törnblom, Aleksei Kulaev and contributors, GPL-3.0-or-later toolchain; target components also contain individual BSD/other notices. Preserve all source notices.
- itsPLK/ps5-webkit-autoloader: PLK and contributors, GPL-3.0. Native installer also credits John Törnblom; embedded puff retains its zlib-style notice. Original LICENSE and source headers retained.
- libmicrohttpd 1.0.1: source tarball included in native/deps, LGPL-2.1-or-later/eCos alternatives per upstream. Built statically from source, HTTPS disabled.
- VideoLabs/libmicrodns: LGPL-2.1-or-later.
- sahlberg/libsmb2, tag libsmb2-6.2: LGPL-2.1-or-later per original COPYING and per-file notices. Kerberos disabled. The v6 API is needed by this websrv snapshot.
- websrv's embedded frontend includes xterm.js assets under their embedded MIT notices. Its unrelated homebrew examples and PC host are excluded from the source snapshot; neither participates in the payload build.

The Media icon and UI artwork are original DeusLoader assets. The notification is an adaptation of the SDK hello_world sample and retains its GPL notice. The native ELF distribution includes corresponding source and a build script; users can modify and relink it. Original DeusLoader JavaScript/CSS remains MIT, while combined native artifacts retain applicable GPL/LGPL obligations.

etaHEN and PS5Debug real payloads are not redistributed. Mock fixtures with those names remain simulations.
